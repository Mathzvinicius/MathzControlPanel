@echo off
:: ==============================================================================
:: DESINSTALADOR OFICIAL - MATHZ CONTROL PANEL
:: ==============================================================================

setlocal EnableDelayedExpansion
title Desinstalador Mathz Control Panel

:: 1. Verificar Privilegios de Administrador e Auto-Elevar
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [i] Solicitando permissoes de Administrador...
    powershell -NoProfile -Command "Start-Process cmd -ArgumentList '/c \"\"%~f0\"\"' -Verb RunAs"
    exit /b
)

echo =================================================================
echo       DESINSTALADOR OFICIAL - MATHZ CONTROL PANEL
echo =================================================================
echo.

set "INSTALL_DIR=C:\Program Files\MathzControlPanel"

:: 1. Restaurar Cursores Padrao do Windows
if exist "%INSTALL_DIR%\Apply-Cursors.ps1" (
    echo [*] Restaurando cursores padrao do Windows...
    powershell -NoProfile -ExecutionPolicy Bypass -File "%INSTALL_DIR%\Apply-Cursors.ps1" -RestoreDefault >nul 2>&1
)

:: 2. Remover Atalhos da Area de Trabalho
echo [*] Removendo atalhos da Area de Trabalho...
del /F /Q "%USERPROFILE%\Desktop\Mathz Control Panel.lnk" >nul 2>&1
del /F /Q "%PUBLIC%\Desktop\Mathz Control Panel.lnk" >nul 2>&1

:: 3. Remover Diretorio de Instalacao
echo [*] Removendo arquivos de %INSTALL_DIR%...
if exist "%INSTALL_DIR%" (
    rmdir /S /Q "%INSTALL_DIR%" >nul 2>&1
)

echo.
echo =================================================================
echo DESINSTALACAO CONCLUIDA COM SUCESSO!
echo O Mathz Control Panel foi removido do seu sistema.
echo =================================================================
echo.
pause
