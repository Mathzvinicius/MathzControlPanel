@echo off
:: ==============================================================================
:: INSTALADOR UNIVERSAL DO MATHZ CONTROL PANEL
:: Compativel com QUALQUER Windows 10 e Windows 11 (Home, Pro, Enterprise, etc.)
:: ==============================================================================

setlocal EnableDelayedExpansion
title Instalador Mathz Control Panel

:: 1. Verificar Privilegios de Administrador e Auto-Elevar
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [i] Solicitando permissoes de Administrador...
    powershell -NoProfile -Command "Start-Process cmd -ArgumentList '/c \"\"%~f0\"\"' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"
echo =================================================================
echo        INSTALADOR OFICIAL - MATHZ CONTROL PANEL
echo =================================================================
echo.

:: 2. Definir Diretorios de Instalacao
set "INSTALL_DIR=C:\Program Files\MathzControlPanel"
set "CURSOR_DIR=C:\Windows\Cursors\MathzPerformance"

echo [*] Criando diretorio em: %INSTALL_DIR%
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
if not exist "%CURSOR_DIR%" mkdir "%CURSOR_DIR%"

:: 3. Copiar Arquivos do Painel
echo [*] Instalando arquivos do Mathz Control Panel...
xcopy /E /Y /I "%~dp0MathzControlCenter\*" "%INSTALL_DIR%\" >nul

:: 4. Copiar Cursores Mathz Performance (.CUR Limpos Gamer)
if exist "%~dp0MathzControlCenter\Cursors" (
    echo [*] Instalando cursores Mathz Performance em C:\Windows\Cursors...
    xcopy /E /Y /I "%~dp0MathzControlCenter\Cursors\*.cur" "%CURSOR_DIR%\" >nul
) else if exist "%~dp0assets\cursors\MathzPerformance" (
    echo [*] Instalando cursores Mathz Performance em C:\Windows\Cursors...
    xcopy /E /Y /I "%~dp0assets\cursors\MathzPerformance\*.cur" "%CURSOR_DIR%\" >nul
)

:: 5. Aplicar os Cursores no Sistema
if exist "%INSTALL_DIR%\Apply-Cursors.ps1" (
    echo [*] Aplicando esquema de cursores Mathz Performance...
    powershell -NoProfile -ExecutionPolicy Bypass -File "%INSTALL_DIR%\Apply-Cursors.ps1" >nul 2>&1
) else if exist "%~dp0scripts\09_Apply_Mathz_Cursors.ps1" (
    echo [*] Aplicando esquema de cursores Mathz Performance...
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\09_Apply_Mathz_Cursors.ps1" >nul 2>&1
)

:: 6. Criar Atalho na Area de Trabalho
echo [*] Criando atalho 'Mathz Control Panel' na Area de Trabalho...
powershell -NoProfile -ExecutionPolicy Bypass -File "%INSTALL_DIR%\Create-Desktop-Shortcut.ps1"

echo.
echo =================================================================
echo INSTALACAO CONCLUIDA COM SUCESSO!
echo O Mathz Control Panel ja esta pronto e funcionando no seu Windows.
echo =================================================================
echo.
echo Abrindo o painel agora...
start "" wscript.exe "%INSTALL_DIR%\Launch-MathzControlPanel.vbs"
timeout /t 3 >nul
exit
